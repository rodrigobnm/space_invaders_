// /**
//  * main.h
//  * Created on Aug, 23th 2023
//  * Author: Tiago Barros
//  * Based on "From C to C++ course - 2002"
//  */

// #include <string.h>
// #include "keyboard.h"
// #include "screen.h"
// #include "timer.h"

// #define alturaTela 40
// #define larguraTela 20

// int jogadorX, jogadorY;
// int bulletX, bulletY;
// int bulletAlienX, bulletAlienY;
// char matrizAlien[4][16];
// char matrizTela[alturaTela][larguraTela];

// int keyboardHit();
// void startScreen();
// void screenInit(int drawBorders);
// // Inicializa a tela, limpando-a e posicionando o cursor no início. Se drawBorders for diferente de zero, desenha bordas na tela.
// void screenDestroy();
// // Restaura a tela para o estado inicial, limpando-a.
// void screenGotoxy(int x, int y);
// // Move o cursor para a posição (x, y) especificada.

// int keyboardHit(){

// }