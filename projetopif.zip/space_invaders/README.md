<p align="center">
  <img
    src="https://img.shields.io/badge/Status-Em%20desenvolvimento-green?style=flat-square"
    alt="Status"
  />
</p>

<p align="center">
  <img
    src="https://img.shields.io/github/repo-size/Sofia-Saraiva/Semester3-CESAR-School?style=flat"
    alt="Repository Size"
  />
  <img
    src="https://img.shields.io/github/languages/count/Sofia-Saraiva/Semester3-CESAR-School?style=flat&logo=python"
    alt="Language Count"
  />
  <img
    src="https://img.shields.io/github/commit-activity/t/Sofia-Saraiva/Semester3-CESAR-School?style=flat&logo=github"
    alt="Commit Activity"
  />
  <a href="LICENSE.md"
    ><img
      src="https://img.shields.io/github/license/Sofia-Saraiva/Semester3-CESAR-School"
      alt="License"
  /></a>
</p>

## 🖥️ XYZ

## 📄 Descrição

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

## 🎲 Objetivo do Jogo

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

### ⚾ Múltiplas Bolas:
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

### 👾 Pontuação Duplicada:
Lorem Ipsum has been the industry's standard

### ⚡️ Alta Velocidade:
Lorem Ipsum has been the industry's standard

## 🕹️ Como Jogar

- Use as teclas de seta ou as teclas "w" e "s" para controlar a raquete no lado esquerdo da tela e "i" e "k" para controlar a raquete no lado direito da tela.
- Certifique-se de manter o caps lock desativado.
- Mantenha suas raquetes em movimento para acertar as bolas e marcar pontos.

## ♟️ Executando o Jogo

Para executar o Pong2, siga estas etapas:

1. Clone este repositório em sua máquina:
   `Lorem Ipsum has been the industry's standard`

3. Compile o programa:
   `Lorem Ipsum has been the industry's standard`

4. Rode o programa:
   `Lorem Ipsum has been the industry's standardn`

5. Divirta-se jogando Pong2 com seus amigos!

## 👩‍💻 Membros

<ul>
  <li>
    <a href="https://github.com/fbclipe">Felipe Barros</a> -
    fbc@cesar.school 📩
  </li>
  <li>
    <a href="https://github.com/bernardoheuer">Bernardo Heuer</a> -
    bchg@cesar.school 📩
  </li>
  <li>
    <a href="https://github.com/rodrigobnm">Rodrigo Nunes</a> -
    rbnm@cesar.school 📩
  </li>
</ul>
<!--
<table>
  <tr>
    <td align="center">
      <a href="https://github.com/Thomazrlima">
        <img src="https://avatars3.githubusercontent.com/Thomazrlima" width="100px;" alt="Foto de Thomaz"/><br>
        <sub>
          <b>Thomaz R. Lima</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="https://github.com/hsspedro">
        <img src="https://avatars.githubusercontent.com/hsspedro" width="100px;" alt="Foto de Pedro"/><br>
        <sub>
          <b>Pedro S. Souza</b>
        </sub>
      </a>
    </td>
    <td align="center">
      <a href="https://github.com/Sofia-Saraiva">
        <img src="https://avatars.githubusercontent.com/Sofia-Saraiva" width="100px;" alt="Foto de Sofia"/><br>
        <sub>
          <b>Sofia Saraiva</b>
        </sub>
      </a>
    </td>
  </tr>
</table>
-->
## Licença

Lorem Ipsum has been the industry's standard

#### Deverão ser entregues os seguintes artefatos:

<p>- Código fonte disponível e acessível em repositório no github.</p>
<p>- Makefile/script/linha de comando para compilação do projeto.</p>
<p>- Slides de apresentação do projeto contendo:</p>
<p>. Apresentação do jogo</p>
<p>. Instruções de compilação e uso</p>
<p>. Detalhes de implementação (Lista e descrição das funções, highlights do código, dificuldades encontradas).</p>
<br>

#### Usar obrigatoriamente os seguintes conceitos no jogo:

<p>- Estruturas (structs);</p>
<p>- Ponteiros;</p>
<p>- Alocação dinâmica de memória;</p>
<p>- Matriz ou lista encadeada ou alguma outra estrutura de dados mais complexa;</p>
<p>- Escrita e leitura em arquivo (top scores, por ex.);</p>
